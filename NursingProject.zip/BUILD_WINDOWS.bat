@echo off
setlocal
cd /d "%~dp0"

if "%ANDROID_HOME%"=="" if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if "%ANDROID_SDK_ROOT%"=="" set "ANDROID_SDK_ROOT=%ANDROID_HOME%"

if not exist "%ANDROID_HOME%\platforms\android-36\android.jar" (
  echo [ERROR] Android SDK Platform 36 not found.
  echo Open Android Studio ^> Tools ^> SDK Manager and install Android 16 / API 36.
  pause
  exit /b 2
)

where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle --no-daemon clean assembleDebug
  goto :done
)

echo [INFO] Gradle command not found.
echo Open this project in Android Studio and use Build ^> Build APK(s),
echo or install Gradle 8.13 and run this file again.
pause
exit /b 3

:done
if exist "app\build\outputs\apk\debug\app-debug.apk" (
  echo.
  echo APK built successfully:
  echo %CD%\app\build\outputs\apk\debug\app-debug.apk
) else (
  echo Build finished but APK was not found in the expected path.
)
pause
