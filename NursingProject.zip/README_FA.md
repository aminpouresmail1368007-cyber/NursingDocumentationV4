# پروژه Android Studio — مستندسازی تخصصی پرستاری V4

این پروژه نسخه استاندارد Android Studio است و فایل HTML تخصصی پرستاری را داخل WebView محلی اجرا می‌کند. هیچ مجوز INTERNET در Manifest تعریف نشده است؛ بنابراین اطلاعات فرم به اینترنت ارسال نمی‌شود.

## مشخصات ساخت
- Android Gradle Plugin: 8.13.2
- Gradle پیشنهادی: 8.13
- compileSdk: 36
- targetSdk: 36 (Android 16)
- minSdk: 26
- Java: 17
- applicationId: `com.nursingdoc.prototype`

## ساخت APK در Android Studio
1. Android Studio Meerkat 2024.3.1 یا جدیدتر را نصب کنید.
2. از Tools > SDK Manager، Android SDK Platform 36 را نصب کنید.
3. پوشه پروژه را با File > Open باز کنید.
4. اگر IDE درباره Gradle پرسید، Gradle 8.13 را انتخاب/دانلود کنید.
5. صبر کنید Gradle Sync کامل شود.
6. Build > Build App Bundle(s) / APK(s) > Build APK(s).
7. خروجی Debug معمولاً در این مسیر است:
   `app/build/outputs/apk/debug/app-debug.apk`

APK دیباگ توسط Android Studio با debug keystore استاندارد امضا می‌شود و از روش امضای مدرن APK استفاده می‌کند.

## حساب‌های دمو
- `nurse.icu` / `1234`
- `nurse.transplant` / `1234`
- `head.nurse` / `1234`
- `supervisor` / `1234`
- `admin` / `1234`

## نکته امنیتی
ورود فعلی برای دمو است و کاربران/رمزها داخل asset قرار دارند. برای استفاده واقعی بیمارستانی باید احراز هویت و Audit Log به Backend/Active Directory/HIS منتقل شود و رمزها در HTML نگهداری نشوند.
