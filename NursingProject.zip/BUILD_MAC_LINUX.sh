#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [[ -z "${ANDROID_HOME:-}" && -d "$HOME/Android/Sdk" ]]; then export ANDROID_HOME="$HOME/Android/Sdk"; fi
if [[ -z "${ANDROID_SDK_ROOT:-}" ]]; then export ANDROID_SDK_ROOT="${ANDROID_HOME:-}"; fi

if [[ -z "${ANDROID_HOME:-}" || ! -f "$ANDROID_HOME/platforms/android-36/android.jar" ]]; then
  echo "[ERROR] Android SDK Platform 36 not found. Install Android 16 / API 36 from Android Studio > SDK Manager."
  exit 2
fi

if ! command -v gradle >/dev/null 2>&1; then
  echo "[ERROR] Gradle 8.13 not found. Open the project in Android Studio or install Gradle 8.13."
  exit 3
fi

gradle --no-daemon clean assembleDebug
printf '\nAPK: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
