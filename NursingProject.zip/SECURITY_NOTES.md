# Security notes for production

This repository is a clinical prototype, not a production authentication system.

Before hospital deployment:
1. Move authentication to a server-side identity provider (AD/LDAP/SSO/HIS).
2. Remove demo credentials from the HTML asset.
3. Use server-enforced RBAC and least privilege.
4. Store audit logs server-side with tamper-resistant retention.
5. Use TLS for all network traffic once a backend is introduced.
6. Do not store direct patient identifiers in WebView local/session storage unless hospital security approves the design.
7. Add session timeout, account lockout, password policy, device policy, and revocation.
8. Validate all nursing datasets and clinical triggers against hospital-approved protocols before clinical use.
9. Conduct UAT, privacy review, security testing, and clinical safety review before go-live.
